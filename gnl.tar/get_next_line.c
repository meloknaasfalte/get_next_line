#include "get_next_line.h"

void	ft_strclr(char *s)
{
	int			i;

	i = 0;
	while (s && *(s + i))
	{
		*(s + i) = '\0';
		i++;
	}
}

void	ft_free(char **str, char *p)
{
	char		*tmp;

	tmp = *str;
	free (tmp);
	tmp = NULL;
	*str = p;
}

char	*check_remainder(char *remainder, char **line)
{
	char	*p_n;

	p_n = NULL;
	if (remainder)
	{
		p_n = ft_strchr(remainder, '\n');
		if (p_n)
		{
			*p_n = '\0';
			*line = ft_strdup(remainder);
			ft_strcpy(remainder, ++p_n);
		}
		else
		{
			*line = ft_strdup(remainder);
			ft_strclr(remainder);
		}
	}
	else
	{
		*line = ft_strdup("");
	}
	return (p_n);
}

int	ft_return(char **remainder)
{
	if (*remainder)
	{
		free(*remainder);
		*remainder = 0;
	}
	return (0);
}

int	get_next_line(int fd, char **line)
{
	char		buf[BUFF_SIZE + 1];
	int			result;
	char		*p_n;
	static char	*remainder;

	result = 1;
	if (fd < 0 || BUFF_SIZE <= 0 || read(fd, buf, 0))
		return (-1);
	p_n = check_remainder(remainder, line);
	while (result && !p_n)
	{
		result = read(fd, buf, BUFF_SIZE);
		buf[result] = '\0';
		p_n = ft_strchr(buf, '\n');
		if (p_n)
		{
			*p_n = '\0';
			ft_free(&remainder, ft_strdup(++p_n));
		}
		ft_free(line, ft_strjoin(*line, buf));
	}
	if (result)
		return (1);
	return (ft_return(&remainder));
}
//int main(void)
//{
//	char	*line;
//	int 	fd;
//	int 	res;
//	int 	counter;
//
//	counter = 0;
//	fd = open("gnlTester/files/42_with_nl", O_RDONLY);
//	while (1)
//	{
//		res = get_next_line(fd, &line);
//		printf("#%i, res: %i - %s\n", counter, res, line);
//		free(line);
//		counter++;
//		if (res == 0 || res == -1)
//			break;
//	}
//}
